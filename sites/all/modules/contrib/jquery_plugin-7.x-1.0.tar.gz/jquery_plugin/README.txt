// $Id: README.txt,v 1.1.4.4.2.1 2009/09/24 00:39:19 mfb Exp $

The jquery_plugin module allows you to load miscellaneous jQuery plugins 
from any module by calling the drupal_add_library() function. For 
example, drupal_add_library('jquery_plugin', 'validate') would load the 
validation plugin.
	
More information about jQuery plugins can be found at 
http://plugins.jquery.com/project/Plugins
