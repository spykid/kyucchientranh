
CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Installation
 * Usage

INTRODUCTION
------------

Simplenews Content Selection offer a way to select nodes, automatically
aggregates these in a simplenews newsletter node.


INSTALLATION
------------

* Install as usual, see http://drupal.org/node/70151 for further information.

* Note that you will need the Simplenews module as it is a dependency.


USAGE
-----

Go to admin/content/scs_node_selection and chose nodes to create a newsletter
with, then order them in a next screen: a newsletter node will then be saved.
You can edit as any newsletter node and then send it.

For further documentation on sending newsletters, refer to the simplenews
module.