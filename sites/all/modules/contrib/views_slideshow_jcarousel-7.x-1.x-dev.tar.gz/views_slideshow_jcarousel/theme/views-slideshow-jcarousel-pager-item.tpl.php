<li<?php print $attributes; ?>>
  <?php print $item; ?>
</li>
